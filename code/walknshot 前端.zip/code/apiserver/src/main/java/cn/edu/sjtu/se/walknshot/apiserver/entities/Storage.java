package cn.edu.sjtu.se.walknshot.apiserver.entities;

public class Storage {
    int id;
    String filename;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFilename() {
        return filename;
    }

    public void setFilename(String filename) {
        this.filename = filename;
    }
}
