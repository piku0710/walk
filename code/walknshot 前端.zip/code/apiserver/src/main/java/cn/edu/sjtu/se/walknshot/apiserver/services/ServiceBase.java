package cn.edu.sjtu.se.walknshot.apiserver.services;

import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class ServiceBase {
    //protected final SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
}
